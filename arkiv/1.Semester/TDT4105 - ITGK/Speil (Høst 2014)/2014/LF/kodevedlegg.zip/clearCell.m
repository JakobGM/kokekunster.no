function board = clearCell(board)
    row = input('Velg rad (1-9) � slette fra:');
    col = input('Velg kolonne (1-9) � slette fra:');
    
    if ~isValidNumber(row)
        fprintf('%d er ikke en gyldig rad. Vennligst skriv inn et tall mellom 1 og 9\n', row);
    elseif ~isValidNumber(col)
        fprintf('%d er ikke en gyldig kolonne. Vennligst skriv inn et tall mellom 1 og 9\n', col);
    else
        board(row, col) = 0;
    end
    
end