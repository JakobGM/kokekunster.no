function board = writeNumber(board)
    [row, col, num] = readNumberAndPosition();
    if ~isValidNumber(row)
        fprintf('%d er ikke en gyldig rad. Vennligst skriv inn et tall mellom 1 og 9\n', row);
    elseif ~isValidNumber(col)
        fprintf('%d er ikke en gyldig kolonne. Vennligst skriv inn et tall mellom 1 og 9\n', col);
    elseif ~isValidNumber(num)
        fprintf('%d er ikke et gyldig tall. Vennligst skriv inn et tall mellom 1 og 9\n', num);
    elseif ~isLegalNumber(board, row, col, num)
        fprintf('%d,%d er ikke en lovlig plass for %d\n', row, col, num);
    else
        board(row, col) = num;
    end
end