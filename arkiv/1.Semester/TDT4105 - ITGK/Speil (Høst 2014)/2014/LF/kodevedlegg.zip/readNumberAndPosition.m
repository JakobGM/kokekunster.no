function [row, col, number] = readNumberAndPosition()
    row = input('Velg rad (1-9):');
    col = input('Velg kolonne (1-9):');
    number = input('Velg tall (1-9):');
end