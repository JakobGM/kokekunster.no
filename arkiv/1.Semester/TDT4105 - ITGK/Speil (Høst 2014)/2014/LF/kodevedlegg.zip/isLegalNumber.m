function res = isLegalNumber(board, row, col, num)
    res = true;
    % Sjekk kolonne
    for i=1:9
        % Sjekker om tallet allerede er i kolonnen
        if board(i, col) == num && row ~= i
            res = false;
            break
        end
    end
    % Sjekk rad
    for j=1:9
        % Sjekker om tallet allerede er i kolonnen
        if board(row, j) == num && col ~= j
            res = false;
            break
        end
    end
    
    % Sjekk boks
    % Finner hvilken boks tallet er i
    if row <= 3
        boxRow = 1;
    elseif row <= 6;
        boxRow = 4;
    else
        boxRow = 7;
    end
    
    if col <= 3
        boxCol = 1;
    elseif col <= 6;
        boxCol = 4;
    else
        boxCol = 7;
    end
    
    for i=boxRow:boxRow+2
        for j=boxCol:boxCol+2
            % Sjekker om tallet allerede er i boksen
            if board(i, j) == num && row ~= i && col ~= j
                res = false;
                break
            end
        end
    end
end
