function res = isSolution(board)
    res = true;
    for i=1:9
        for j=1:9
            num = board(i, j);
            if num == 0 || ~isLegalNumber(board,i,j, num)
                res = false;
                return
            end
        end
    end
end