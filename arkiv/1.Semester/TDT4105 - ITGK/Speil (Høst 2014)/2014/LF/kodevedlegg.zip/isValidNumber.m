function res = isValidNumber(number)
    if number >= 1 && number <= 9
        res = true;
    else
        res = false;
    end
end