function playSudoku()
    
    board = -1;
    while board == -1
        boardFile = input('Skriv inn filnavn til brett:','s');
        board = readBoardFromFile(boardFile);
    end
        
    while true
        printBoard(board);
        if isSolution(board)
            fprintf('Gratulerer, du har l�st brettet!');
        end
        fprintf('Hva vil du gj�re?\n');
        fprintf('1. Fyll inn nytt tall\n');
        fprintf('2. Fjerne et tall\n');
        fprintf('3. Lagre brettet til fil\n');
        fprintf('4. Avslutte spillet\n');

        choice = input('');

        switch choice
            case 1
                board = writeNumber(board);
            case 2
                board = clearCell(board);
            case 3
                filename = input('Skriv inn filnavn � lagre til: ', 's');
                saveBoardToFile(board, filename);
            case 4
                return % Avslutter hele programmet
        end
    end
end