function board = readBoardFromFile(filename)
    board = zeros(9,9);
    
	fileID = fopen(filename, 'r');
    
    if fileID == -1
        fprintf('Finner ikke angitt fil');
        board = -1;
        return
    end
    
	for i = 1:9
        line = fgetl(fileID);
	    for j = 1:9
            board(i,j) = str2double(line(j));
        end
	end
	
	fclose(fileID);
    board
    
end