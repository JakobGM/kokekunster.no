function printBoard(board)
    fprintf('    1 2 3   4 5 6   7 8 9\n   ----------------------- \n');
    for i = 1:9
        fprintf('%d |', i);
        for j = 1:9
            
            if board(i, j) == 0
                fprintf('  ');
            else
                fprintf(' %d', board(i,j));
            end
            
            if mod(j,3) == 0
                fprintf(' |');
            end
        end
        fprintf('\n');
        if mod(i,3) == 0
            fprintf('   ----------------------- \n');
        end
    end
end