function saveBoardToFile(board, filename)
 
	fileID = fopen(filename, 'w');
    
    	for i = 1:9
     	    for j = 1:9
                fprintf(fileID, '%d', board(i,j));
            end
            fprintf(fileID, '\n');
        end
	
	fclose(fileID);
    
end