def sok(ord, tekst):
    pos = 0
    while (len(ord) + pos <= len(tekst)):
        if (tekst[pos:len(ord)+pos] == ord):
            return 1
        else:
            pos+=1     
    
    return 0

print(sok('bob', 'The numbers '))
