def leggTilFag(alleFag):
    fagKode = input('Fagkode:')
    oppmeldte = int(input('Antall oppmeldte:'))
    obligatorisk = input('Obligatorisk øvingsopplegg:')
    obligatorisk = (obligatorisk == 'ja')

    for x in range(0,len(alleFag)):
        if (alleFag[x][0] == fagKode):
            print('Faget finnes fra før av!')
            return alleFag
        else:
            alleFag.append([fagKode, oppmeldte, obligatorisk])

    return alleFag
