def jumpSum(list):
    sum = 0
    for x in range(0,len(list), 2):
        sum+=list[x]
    
    return sum

