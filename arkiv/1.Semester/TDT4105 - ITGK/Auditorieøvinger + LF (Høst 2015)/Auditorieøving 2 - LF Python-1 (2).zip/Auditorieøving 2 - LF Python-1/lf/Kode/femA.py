def planlegging(list):
    for x in range(0,len(list)):
        if (list[x]==3)
            list.pop(x)
            list.append(x)

    return list
