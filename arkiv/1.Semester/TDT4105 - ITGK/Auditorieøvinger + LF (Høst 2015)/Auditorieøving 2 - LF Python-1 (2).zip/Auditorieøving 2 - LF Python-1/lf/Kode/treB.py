def sumJumpMat(matrix):
    sum = 0
        for x in range(0,len(matrix)):   
            if (x%2):
                sum+= jumpSum(matrix[x][0:len(matrix[0])]
            else:
                sum+= jumpSum(matrix[x][1:len(matrix[0])]

    return sum

def sumJumpMat(matrix):
    sum = 0
    for x in range(0,len(matrix)):   
        sum+=jumpSum(matrix[x][x%2:len(a[0])])

return sum


def sumJumpMat(matrix):
return sum(jumpSum(matrix[x][x%2:len(matrix[0])]) for x in range(0,len(matrix)))   
