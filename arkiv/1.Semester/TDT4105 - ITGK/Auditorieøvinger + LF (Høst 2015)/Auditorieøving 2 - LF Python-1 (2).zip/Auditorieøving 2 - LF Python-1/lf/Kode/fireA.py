def scram (a,d,c,b):
    a,b,c,d = c,d,b,a
    if b > c:
        return d,c,b,a
    else :
        return b,d,a,c
    
a,b,c,d = 1,2,3,4
a,c,d,b = scram (a,b,c,d)
print (a,b,c,d)
