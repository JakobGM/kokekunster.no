def duplicates(list):
    newList = []
    for x in range(0,len(list)):
        if not (newList.count(list[x])):
            newList.append(list[x])
    
    return newList

print(duplicates([5,2,2,1,3,4,3,1,3,6,6]))
