def enkeltFag(alleFag):
    for x in range(0,len(alleFag)):
        if (alleFag[x][2]):
            print(alleFag[x][0])
