def incSum(list):
    pos = 1
    length = 1
    while (pos <= len(list)):
        sum += list(pos:(pos+length))
        pos += 1 + length
        length +=1

    return sum
