#include <cstdlib>

#include "minesweeper.h"

using namespace std;

// Naboene til en rute
const int row_offsets[8] = { -1, -1, -1,  0,  0,  1, 1,  1 };
const int col_offsets[8] = { -1,  0,  1, -1,  1, -1, 0,  1 };

Minesweeper::Minesweeper(int width, int height, int mines) {
    this->width  = width;
    this->height = height;
    this->game_over = false;

    board = new Tile[width * height];

    for(int i = 0; i < mines; ++i) {
        int row, col;

        // Velg en tilfeldig rute til vi finner en som er tom
        do {
            row = rand() % height;
            col = rand() % width;
        } while(board[index(row, col)].mine);

        // ... og legg en mine der
        board[index(row, col)].mine = true;
    }

    for(int row = 0; row < height; ++row) {
        for(int col = 0; col < width; ++col) {
            int numAdjacentMines = 0;
            for(int i = 0; i < 8; ++i) {
                const int neighbour_row = row + row_offsets[i];
                const int neighbour_col = col + col_offsets[i];

                if(inside(neighbour_row, neighbour_col) && board[index(neighbour_row, neighbour_col)].mine) {
                    numAdjacentMines++;
                }
            }

            board[index(row, col)].numAdjacentMines = numAdjacentMines;
       }
    }
}

Minesweeper::~Minesweeper() {
    delete [] board;
}

int Minesweeper::index(int row, int col) const {
    return row * width + col;
}

bool Minesweeper::inside(int row, int col) const {
    return row >= 0 && row < height && col >= 0 && col < width;
}

void Minesweeper::openNeighbours(int row, int col) {
    for(int i = 0; i < 8; ++i) {
        int neighbour_row = row + row_offsets[i];
        int neighbour_col = col + col_offsets[i];

        if(inside(neighbour_row, neighbour_col) && !board[index(neighbour_row, neighbour_col)].open) {
            board[index(neighbour_row, neighbour_col)].open = true;
            if(board[index(neighbour_row, neighbour_col)].numAdjacentMines == 0) {
                openNeighbours(neighbour_row, neighbour_col);
            }
        }
    }
}

bool Minesweeper::isGameOver() const {
    return game_over;
}

bool Minesweeper::isTileOpen(int row, int col) const {
    return board[index(row, col)].open;
}

bool Minesweeper::isTileMine(int row, int col) const {
    return board[index(row, col)].mine;
}

void Minesweeper::openTile(int row, int col) {
    board[index(row, col)].open = true;

    if(board[index(row, col)].mine) {
        game_over = true;
    }
    else if(board[index(row, col)].numAdjacentMines == 0) {
        openNeighbours(row, col);
    }
}

int Minesweeper::numAdjacentMines(int row, int col) const {
    return board[index(row, col)].numAdjacentMines;
}
