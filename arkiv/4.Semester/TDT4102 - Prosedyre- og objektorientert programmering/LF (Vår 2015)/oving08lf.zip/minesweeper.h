#pragma once

struct Tile {
    bool open;
    bool mine;
    int numAdjacentMines;

    Tile(): open(false), mine(false), numAdjacentMines(0) {}
};

class Minesweeper {
private:
    int width;
    int height;
    bool game_over;
    Tile *board;

    int index(int row, int col) const;
    bool inside(int row, int col) const;

    void openNeighbours(int row, int col);

public:
    Minesweeper(int width, int height, int mines);
    ~Minesweeper();

    bool isGameOver() const;

    bool isTileOpen(int row, int col) const;
    bool isTileMine(int row, int col) const;

    void openTile(int row, int col);

    int numAdjacentMines(int row, int col) const;

    // Slå av default kopikonstruktør og tilordningsoperator
    Minesweeper(const Minesweeper &) = delete;
    Minesweeper &operator=(const Minesweeper &) = delete;
};
