#include <iostream>
#include "utilities.h"

using namespace std;

int randomWithLimits(int lower, int upper) {
	return lower + (rand() % (upper - lower + 1));
}

char randomCharWithLimits(int lower, int upper) {
	return lower + (rand() % (upper - lower + 1));
}

void incrementByValueNumTimes(int *value, int increment, int numTimes) {
	for (int i = 0; i < numTimes; i++) {
		*value += increment;
	}
}

void swapNumbers(int *first, int *second) {
	int temp = *first;
	*first = *second;
	*second = temp;
}

void printArray(int array[], int size) {
	for (int i = 0; i < size; i++) {
		cout << array[i] << " ";
	}
	cout << endl;
}

void randomizeArray(int array[], int size) {
	for (int i = 0; i < size; i++) {
		array[i] = randomWithLimits(0, 100);
	}
}

void sortArray(int array[], int size) {
	for (int i = 1; i < size; i++) {
		for (int j = i; j > 0; j--) {
			if (array[j] < array[j - 1]) {
				swapNumbers(&array[j], &array[j-1]);
			} else {
				break;
			}
		}
	}
}

int medianOfArray(int array[], int size) {
	if (size == 1) {
		return array[0];
	} else 	if (size % 2) {
		return (array[(size - 1) / 2]);
	} else {
		return (array[(size - 1)/2] + array[((size - 1)/2) + 1]) / 2;
	}
}

void randomizeCString(char cstring[], int length, int lowerLimit, int upperLimit) {
	for (int i = 0; i < length; i++) {
		cstring[i] = randomCharWithLimits(lowerLimit, upperLimit);
	}
	cstring[length] = '\0';
}

void readInputToCString(char cstring[], int length, int lowerLimit, int upperLimit) {
	for (int i = 0; i < length; i++) {
		cin >> cstring[i];
		cstring[i] = toupper(cstring[i]);
		if (cstring[i] < lowerLimit || cstring[i] > upperLimit) {
			cout << "Ugyldig tegn: " << cstring[i] << endl;
			i--;
		}
	}
	cstring[length] = '\0';
}

int countOccurencesOfCharacter(char cstring[], int length, char character) {
	int count = 0;
	for (int i = 0; i < length; i++) {
		if (cstring[i] == character) {
			count++;
		}
	}
	return count;
}
