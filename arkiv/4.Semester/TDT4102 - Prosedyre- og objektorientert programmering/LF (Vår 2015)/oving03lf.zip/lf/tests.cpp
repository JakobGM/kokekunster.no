#include <iostream>
#include <cmath>
#include <iomanip>
#include "tests.h"
#include "utilities.h"

using namespace std;

void testPart2() {
	int v0 = 5;
	int increment = 2;
	int iterations = 10;
	incrementByValueNumTimes(&v0, increment, iterations);
	cout << "v0: " << v0
		<< " increment: " << increment
		<< " iterations: " << iterations << endl;
	// v0 vil være 5 i den originale koden.
}

void testPart3() {
	int percentages[20] = {0};

	randomizeArray(percentages, 20);
	printArray(percentages, 20);
	swapNumbers(&percentages[0], &percentages[1]);
	cout << "Median: " << medianOfArray(percentages, 20) << endl;
	sortArray(percentages, 20);
	cout << "Median: " << medianOfArray(percentages, 20) << endl;
	printArray(percentages, 20);
}

void testPart4() {
	char grades[9];
	randomizeCString(grades, 8, 'A', 'F');
	cout << grades << endl;

	int gradeCount[6] = {0};

	for (int i = 0; i < 6; i++) {
		gradeCount[i] = countOccurencesOfCharacter(grades, 8, 'A' + i);
	}
	cout << "Occurences of A-F: ";
	printArray(gradeCount, 6);

// Average:
	double average = 0.0;
	int sum = 0;
	for (int i = 0; i < 6; i++) {
		average += (gradeCount[i] * (i + 1));
		sum += gradeCount[i];
	}
	average = average / sum;
	cout << "Average: " << average << endl;

	// 5 Years:
	for (int i = 0; i < 6; i++) {
		gradeCount[i] = 0;
	}

	for (int year = 0; year < 5; year++) {
		randomizeCString(grades, 8, 'A', 'E');
//		cout << "Give grades for year " << year + 1 << " : " << endl;
//		readInputToCString(grades, 8, 'A', 'E');
		for (int i = 0; i < 6; i++) {
			gradeCount[i] += countOccurencesOfCharacter(grades, 8, 'A' + i);
		}
	}
	printArray(gradeCount, 6);	
	average = 0.0;
	for (int i = 0; i < 6; i++) {
		average += (gradeCount[i] * (i + 1));
		sum += gradeCount[i];
	}
	average = average / sum;
	cout << "5 Year Average: " << setprecision(1) << fixed << average << " Rounded " << round(average) << " Grade: " << (char)('A' + round(average) - 1) << endl;
}
