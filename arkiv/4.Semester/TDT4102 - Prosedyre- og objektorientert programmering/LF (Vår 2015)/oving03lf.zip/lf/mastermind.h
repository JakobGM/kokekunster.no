#pragma once

int checkCharactersAndPosition(char code[], char guess[], int size);
int checkCharacters(char code[], char guess[], int size, int differentLetters);
void playMastermind();

