#include <iostream>
#include "Matrix2x2.h"
#include "Vector2.h"

using namespace std;

void getDouble( const char * label, double & var );

int main()
{
	double a, b, c, d, p, q;
	cout << "Enter coefficients:" << endl;
#if 0
	getDouble("a", a);
	getDouble("b", b);
	getDouble("p", p);

	getDouble("c", c);
	getDouble("d", d);
	getDouble("q", q);
#else
	a = 2;
	b = 3;
	p = 8;

	c = 1;
	d = -1;
	q = -1;
#endif
	Matrix2x2 A(a,b,c,d);
	Vector2 B(p,q);

	Matrix2x2 InverseA;
	if ( A.Inverse(InverseA) )
	{
		
		cout << "A:\n" << A
			 << "A^-1:\n" << InverseA 
			 << "det(A): " << A.Det()
			 << "\nB:\n" << B
			 << "I\n" << A*InverseA
			 << "I\n" << InverseA*A
			 << "I\n" << Matrix2x2();
		
		cout << "The solution is:\n" << InverseA*B << endl;
	}
	else {
		cout << "The system has no solution." << endl;
	}

	system("pause");
	return 0;
}

void getDouble( const char * label, double & var )
{
	
	while(true) {
		cout << "Enter " << label << ": ";
		cin >> var;

		if (!cin.good())  // Error-handling
		{
			cin.clear(); // Reset error-flags
			cin.ignore(256, '\n'); // Ignore rest of invalid input.
			cout << "Not a double value. Try again." << endl;
		}
		else
			break;
	}
}

//2x + 3y = 8
//x - y  = -1

