#pragma once

#include <iostream>

//Forward Declaration.
class Vector2;

class Matrix2x2 {
	double data[2][2];
public:
	Matrix2x2() {
		data[0][0] = 1.0;
		data[0][1] = 0.0;
		data[1][0] = 0.0;
		data[1][1] = 1.0;
	}

	Matrix2x2( double a, double b, double c, double d) {
		data[0][0] = a;
		data[0][1] = b;
		data[1][0] = c;
		data[1][1] = d;
	}

	void Set(unsigned int row, unsigned int column, double value) {
		data[row][column] = value;
	}

	const double Get(unsigned int row, unsigned int column) const {
		return data[row][column];
	}

	double Det() const;
	bool Inverse( Matrix2x2 & out ) const; // We have chosen the second alternative to handle singular matrices.

	Matrix2x2 & operator +=(const Matrix2x2 & rhs);
	Matrix2x2 & operator -=(const Matrix2x2 & rhs);

	Matrix2x2 operator -(const Matrix2x2 & rhs) const;
	Matrix2x2 operator +(const Matrix2x2 & rhs) const;

	Matrix2x2 operator *(const Matrix2x2 & rhs) const;
	Matrix2x2 & operator *=(const Matrix2x2 & rhs);

	Vector2 operator*(const Vector2 & rhs ) const;
};

std::ostream & operator<<( std::ostream & out, const Matrix2x2 & elem );


