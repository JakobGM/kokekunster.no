#include "Image.h"
#include "Shape.h"
#include "Canvas.h"

#include <cmath>
#include <iostream>
#include <cstdlib>

using namespace std;

const unsigned int img_width = 200, img_height = 200;

const double PI = acos( -1.0 );

int main() {
	// Create a blank Canvas
	Canvas canvas;

	// Create a blue rectangle around the border.
	Rectangle rect( 0, 0, img_width - 1, img_height - 1, Color( 0, 0, 255 ) );
	canvas.addShape( &rect );

	// Test lines.
	Line steepline( -5, 0, 200, 400, Color( 255, 0, 0 ) );
	Line gentleline( 0, -100, 600, 200, Color( 0, 255, 0 ) );

	canvas.addShape( &steepline );
	canvas.addShape( &gentleline );

	// Pretty picture with rings.
	unsigned int n_rings = 0;
	cout << "Enter a number of rings: ";
	cin >> n_rings;


	Circle **rings = new Circle * [n_rings];

	int small_r = 30;
	int big_r = 50;

	// Generate a lot of circles with pretty colors.
	for ( unsigned int i = 0; i < n_rings; i++ ) {
		double v_sin = sin( 2 * PI * i / n_rings );
		double v_cos = cos( 2 * PI * i / n_rings );

		Color ringColor( static_cast<unsigned char>( ( floor( 255 * ( 0.5 * sin( 4 * PI * i / n_rings ) + 0.5 ) ) ) ), static_cast<unsigned char>( floor( 255 * ( 0.5 * v_cos + 0.5 ) ) ), 255 );

		rings[i] = new Circle( static_cast<int>( floor( img_width / 2 + big_r * v_cos ) ), static_cast<int>( floor( img_height / 2 + big_r * v_sin ) ), small_r, ringColor );

		canvas.addShape( rings[i] );
	}

	// Create an Image.
	Image img( img_width, img_height );
	// Set background to white.
	img.fill( Color( 255, 255, 255 ) );

	// Rasterize the Canvas.
	canvas.rasterizeTo( img );

	saveImage( img, "Pretty Picture.bmp" );

	// Create the additive Image:
	Image *newImg = loadImage( "old.bmp" );
	if ( newImg != NULL ) {

		// Rasterize the Canvas.
		canvas.rasterizeTo( *newImg );

		saveImage( *newImg, "Pretty Picture - additive.bmp" );

		delete newImg;
	}

	// Cleanup:
	for ( unsigned int i = 0; i < n_rings; i++ ) {
		delete rings[i];
	}
	delete [] rings;

	return 0;
}
