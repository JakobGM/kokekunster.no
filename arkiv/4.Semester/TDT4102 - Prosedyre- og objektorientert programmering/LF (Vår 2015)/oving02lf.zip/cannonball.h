#ifndef _cannonball
#define _cannonball


const double intStep = 0.001;

double acclY(); //1

double velY(double startVel, double t);//1

double velIntY(double startVel, double t);//1

double posX(double startVel, double t);//1
double posY(double startVel, double t);//1

double posIntX(double startVel, double t);//1
double posIntY(double startVel, double t);//1

void printTime(double t); //1

double flightTime(double startVelY); //1

void getUserInput(double *theta, double *absVelocity); //2

double getVelocityX(double theta, double absVelocity); //2
double getVelocityY(double theta, double absVelocity); //2
void getVelocityVector(double theta, double absVelocity, double *velocityX, double *velocityY); //2
double getDistanceTraveled(double velocityX, double velocityY);
double optimalAngleForMaxDistance(double absVelocity); //2

double targetPractice(double distanceToTarget, double velocityX, double velocityY); //2

void playTargetPractice(); //3
#endif
