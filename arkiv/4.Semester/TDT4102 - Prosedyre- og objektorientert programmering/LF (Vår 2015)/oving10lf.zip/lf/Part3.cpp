#include <iostream>
#include <string>
#include <list>
using namespace std;

/**	Part 3a **/
class Person{
private:
	string firstName;
	string lastName;
public:
	Person(string f, string l) : firstName(f), lastName(l){}
	string getFirstName(){return firstName;}
	string getLastName(){return lastName;}
	
	bool operator <(Person& p);
	friend ostream& operator <<(ostream& out, Person& p);
};


/**	Part 3b **/
void insert(list<Person> &p, Person person);


int main(){
	list<Person> persons;
	insert(persons, Person("Trond", "Aalberg"));
	insert(persons, Person("Arne", "Aalberg"));
	insert(persons, Person("Trine", "Bakke"));
	insert(persons, Person("Ola", "Norman"));
	insert(persons, Person("Kari", "Norman"));
	
/**	Part 3c
	Print the list, using an iterator **/
	list<Person>::iterator pit;
	for (pit = persons.begin(); pit != persons.end(); ++pit){
		cout << *pit << endl;
	}
	
	return 0;
}

/**	Part 3a
	The < is overloaded so we can compare Person objects directly,
	instead of comparing their members, when we insert them in an ordered list in part 3b **/
bool Person::operator <(Person& p){
	//concatenate last + first and compare
	if ((lastName + firstName) < (p.lastName + p.firstName)){
		return true;
	}
	return false;
}

/**	Standard overloading of <<, similar as in previous exercises**/
ostream& operator <<(ostream& out, Person& p){
	out << p.lastName << ", " << p.firstName;
	return out;
}

/**	Part 3b **/
void insert(list<Person> &p, Person person){
	list<Person>::iterator pit;
	for (pit = p.begin(); pit != p.end(); ++pit){	//Iterate through the list
		if (person  < *pit){			//until we reach an element that is larger than the element we wish to insert
			p.insert(pit, person);		//and insert out element at the found position.
			return;
		}
	}
	p.push_back(person);				//If there is no element in the list larger than the one we wish to insert,
}							//the element is inserted at the back of the list.
