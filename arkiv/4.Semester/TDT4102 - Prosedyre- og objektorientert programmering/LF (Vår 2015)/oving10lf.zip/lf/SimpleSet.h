#pragma once

class SimpleSet{
    public:
        SimpleSet();
        bool insert(int i);
        bool exists(int i);
        bool remove(int i);
    private:
        int *data;
        int find(int i);
        int currentSize;
        int maxSize;       
        void resize(int n); 
};

