#include <iostream>
#include <string>
#include <ctime>
#include <cstdlib>
using namespace std;

/**	Part 1a
	The algorithm for shuffling is the same as in exercise 4
	(The algorithm is known as "Fisher-Yates shuffle" or "Knuth shuffle") **/
template<typename T>				//template<class T> can also be used
void shuffle(T a[], int size){
	for (int i = 0; i < size - 1; i++){
		int j = rand() % (size - i);
		T tmp = a[i];
		a[i] = a[i + j];
		a[i + j] = tmp;
	}

}

/**	Part 1b **/
template<typename T>
T maximum(T a, T b){
	
	if (b < a){
		return a;
	}else{
		return b;
	}
}

/**	Part 1c: The function maximum requires the operator < for type T **/



int main(){
	srand(time(NULL));
	
	int a[] = {1,2,3,4,5,6,7};
	shuffle(a, 7);
	for (int i = 0; i < 7; i ++){
		cout << a[i] << " ";
	}
	cout << endl;

	double b[] = {1.1, 2.2, 3.3, 4.4};
	shuffle(b, 4);
	for (int i = 0; i < 4; i ++){
		cout << b[i] << " ";
	}
	cout << endl;

	string c[] = {"one", "two", "three", "four"};
	shuffle(c, 4);
	for (int i = 0; i < 4; i ++){
		cout << c[i] << " ";
	}
	cout << endl << endl;

	
	cout << "maximum(1, 2) = " << maximum(1, 2) << endl;
	cout << "maximum(1.0, 2.3) = " << maximum(1.0, 2.3) << endl;
	cout << "maximum('X', 'Y') = " <<maximum('X', 'Y') << endl;
	cout << "maximum(string(\"tre\"), string(\"fire\")) = " << maximum(string("tre"), string("fire")) << endl;
	
	return 0;
	
}
