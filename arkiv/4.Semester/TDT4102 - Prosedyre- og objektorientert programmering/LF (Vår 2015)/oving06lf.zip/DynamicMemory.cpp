#include <algorithm> // for std::min
#include <iostream>
#include "DynamicMemory.h"
#include "utilities.h"

using namespace std;

void fibonacciSequenceOfOrder(int order, int result[], int length) {
	int i = 0;
	for(; i < min(order-1, length); ++i) {
	   result[i] = 0;
	}

	if(length < order) return;

	result[i++] = 1;

	for(; i < length; ++i) {
		result[i] = result[i-1] + result[i-2];
	}
}

void testFibonacciSequenceOfOrder() {
	cout << "Hvilken orden?" << endl;

	int order;
	cin >> order;

	cout << "Hvor mange tall?" << endl;
	int length;
	cin >> length;

	int *result = new int[length];
	fibonacciSequenceOfOrder(order, result, length);

	printArray(result, length);

	delete [] result;
}
