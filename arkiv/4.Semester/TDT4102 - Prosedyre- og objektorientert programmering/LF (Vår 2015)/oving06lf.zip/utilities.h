#ifndef UTILITIES_H
#define UTILITIES_H

void printArray(int array[], int length);

#endif
