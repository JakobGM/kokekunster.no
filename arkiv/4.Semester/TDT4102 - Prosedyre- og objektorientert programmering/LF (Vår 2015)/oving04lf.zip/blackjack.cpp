#include <iostream>
#include "blackjack.h"

using namespace std;

bool BlackJack::isAce(Card* c){
    if (c->getRank() == ACE){
        return true;
    }
    else{
        return false;    
    }
}

int BlackJack::getCardValue(Card* c){
    Rank r = c->getRank();
    if (r == ACE){
        return -1;    
    }
    else if (r+2 > 10){
        return 10; 
    }
    else{
        return r+2;
    }
}

int BlackJack::getPlayerCardValue(Card* c){
    if (isAce(c)){
        cout << "You got an ace, should we value it as 1 or 11?" << endl;
        int input = -1;
        cin >> input;
        while (!(input == 1 || input == 11)){
            cout << "That is not a valid response, please enter 1 or 11." << endl;
            cin >> input;
        }
        return input;
    }
    else{
        return getCardValue(c);
    }
}

int BlackJack::getDealerCardValue(int hand, Card* c){
    if (isAce(c)){
        if (hand+11 <= 21){
            return 11;
        }
        else{
            return 1;
        }
    }
    else{
        return getCardValue(c);
    }
}

bool BlackJack::askPlayerDrawCard(){
    cout << "Do you want another card (1/0)?" << endl;
    bool input;
    cin >> input;
    return input;
}

bool BlackJack::playGame(){
    cout << "******* LETS PLAY BLACKJACK! *********" << endl;
    deck.shuffle();
    Card *p;
    bool win = true, burst = false, playerPassed = false;
    int cardValue, round = 1, playerHand = 0, dealerHand = 0;

    p = deck.drawCard();
    cout << "You got: " << p->toString() << endl;
    playerHand += getPlayerCardValue(p);

    p = deck.drawCard();
    cout << "You got: " << p->toString() << endl;
    playerHand += getPlayerCardValue(p);

    p = deck.drawCard();
    cout << "Dealer got: " << p->toString() << endl;
    dealerHand += getDealerCardValue(dealerHand,p);

    p = deck.drawCard();
    cout << "Dealer got: " << p->toString() << endl;
    dealerHand += getDealerCardValue(dealerHand,p);
    
    while (playerHand < 21 && dealerHand < 21 && playerPassed == false){
        cout << "************* ROUND " << round << " ****************" << endl;
        cout << "Your hand is currently: " << playerHand << endl;
        cout << "Dealers hand is currently: " << dealerHand << endl;

        if (playerPassed == false && askPlayerDrawCard()){
            cout << "Player draws a card" << endl;
            p = deck.drawCard();
            cout << "You got: " << p->toString() << endl;
            playerHand += getPlayerCardValue(p);
        }
        else{
            cout << "Player stands firm" << endl;
            playerPassed = true;
        }
        if (dealerHand < 17){
            cout << "Dealer draws a card." << endl;   
            p = deck.drawCard();
            cout << "Dealer got: " << p->toString() << endl;
            dealerHand += getDealerCardValue(dealerHand,p);
        }
        else{
            cout << "Dealer stands firm." << endl;
        }
        cout << "**************************************" << endl;
    }
    cout << "Players hand: " << playerHand << endl;
    cout << "Dealers hand:" << dealerHand << endl;
    
    if (playerHand > 21){
        cout << "Player burst." << endl;
        win = false;
    }
    else if (dealerHand > 21){
        cout << "Dealer burst." << endl;
    }
    else if (playerHand == 21){
        cout << "Player got blackjack!" << endl;
    }
    else if (dealerHand == 21){
        cout << "Dealer got blackjack!" << endl;
        win = false;
    }
    else if (playerHand <= 21 && playerHand > dealerHand){
        cout << "Player beat the dealer." << endl;
    }
    else if (dealerHand <= 21 && dealerHand > playerHand){
        cout << "Dealer beat the player." << endl;
        win = false;
    }
    else {
        cout << "Game was a draw." << endl;
        return false;
    }
    if (win){
        cout << "You won! Congratulations!" << endl;
    }
    else{
        cout << "You lost!" << endl;
    }
    return win;
}

