#pragma once

#include "carddeck.h"
class BlackJack{
    private:
        CardDeck deck;
        int getCardValue(Card* c);
        bool isAce(Card* c);
        int getPlayerCardValue(Card* c);
        int getDealerCardValue(int hand, Card* c);
        bool askPlayerDrawCard();
    public:
        bool playGame();
};

