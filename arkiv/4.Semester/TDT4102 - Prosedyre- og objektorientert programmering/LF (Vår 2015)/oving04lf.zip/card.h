#pragma once
#include <string>

enum Suit{ CLUBS, DIAMONDS, HEARTS, SPADES};
std::string suitToString(Suit s);

enum Rank{ TWO, THREE, FOUR, FIVE, SIX, SEVEN, EIGHT, NINE, TEN, JACK, QUEEN, KING, ACE};
std::string rankToString(Rank r);

struct CardStruct{
    Suit s;
    Rank r;
};

std::string toString(CardStruct c);
std::string toStringShort(CardStruct c);

class Card{
    private:
        Suit s;
        Rank r;
        bool invalid;
    public:
        Card(Suit s, Rank r);
        Card();
        void initialize(Suit s, Rank r);

        Suit getSuit();
        Rank getRank();

        std::string toString();
        std::string toStringShort();
};

