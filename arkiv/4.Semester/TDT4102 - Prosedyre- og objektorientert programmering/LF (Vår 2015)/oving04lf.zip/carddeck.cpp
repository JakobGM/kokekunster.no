#include <iostream>
#include "carddeck.h"

using namespace std;

CardDeck::CardDeck(){
    for (int s = CLUBS; s <= SPADES; s++){
        for (int r = TWO; r <= ACE; r++){
            int index = s * 13 + r;
            cards[index].initialize((Suit)s,(Rank)r);
        }
    }

    currentCardIndex = 0;
}

void CardDeck::print(){
    for (int index = 0; index < 52; index ++){
        cout << cards[index].toString() << endl;
    }
}

void CardDeck::printShort(){
    for (int index = 0; index < 52; index ++){
        cout << cards[index].toStringShort() << " ";
    }
    cout << endl;
}

void CardDeck::swap(int index1, int index2){
    Card temp = cards[index1];
    cards[index1] = cards[index2];
    cards[index2] = temp;
}

void CardDeck::shuffle(){
    for (int index = 0; index < 52; index++){
        int rindex = rand()%52;
        swap(index,rindex);
    }
    currentCardIndex = 0;
}

Card* CardDeck::drawCard(){
    if (currentCardIndex >= 52){
        cout << "The deck has run out of cards" << endl;
        return NULL;
    }
    return &cards[currentCardIndex++];
}

