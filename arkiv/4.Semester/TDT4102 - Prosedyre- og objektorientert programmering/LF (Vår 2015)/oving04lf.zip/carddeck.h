#pragma once

#include "card.h"
class CardDeck{
    private:
        Card cards[52];
        void swap(int index1, int index2);
        int currentCardIndex;
    public:
        CardDeck();
        void print();
        void printShort();
        void shuffle();
        Card* drawCard();
};

