#include <iostream>
#include <cstdlib>
#include <ctime>
#include <algorithm>

#include "Minesweeper.h"

using namespace std;


int main(){
	srand(time(NULL));
	
	MineSweeper myGame;
	myGame.play();
	
	return 0;
}

/**	Part 7b
	Nothing new in this function, just read values from cin and check if they are valid**/
void MineSweeper::getInput(){
	width = 0;
	height = 0;
	mines = 0;
	while(width < 2 || height < 2 || mines < 1 || mines > height * width * 0.5){
		cout << "Enter width, height and mines: ";
		cin >> width >> height >> mines;
	}
}

/**	Part 7c **/
void MineSweeper::makeBoard(){
	board = new int *[height];		//A new array of int pointers of size height is assigned to board
	for(int i = 0; i < height; i++){	//and every pointer in this array is set to point to a new int array
		board[i] = new int[width];	//of size width
		for(int j = 0; j < width; j++)	//Loop through each of these arrays setting the value to zero.
			board[i][j] = 0;
	}
	mask = new int *[height];		//Creates the mask array the same way as the board array
	for(int i = 0; i < height; i++){
		mask[i] = new int[width];
		for(int j = 0; j < width; j++)
			mask[i][j] = 0;
	}
}

/**	Part 7d **/
void MineSweeper::placeMines(){
	int placed = 0;				//Number of mines placed on the board
	while(placed < mines){			//We loop until we have places as many mines as specified by the mines member variable
		int y = rand() % height;	//We get a random square by getting a random row and column
		int x = rand() % width;
		if(board[y][x] != -1){		//If there is not already placed a mine in this square 
			board[y][x] = -1;	//we place a mine (represented by -1)
			placed++;		//and update the counter
			
			/**Next we increment the neighboring fields with a double for-loop
			The max and min functions (found in the algorithm library)
			ensures that for-loops do not cross the array's boundaries**/
			for(int i = max(0, y - 1); i < min(y + 2, height); i++)
				for(int j = max(0, x - 1); j < min(x + 2, width); j++)
					if(board[i][j] != -1)	//We increment the field, if it is not a mine.
						board[i][j]++;
		}
	}
}

/**	Part 7e **/
void MineSweeper::setFlag(int y, int x){
	if(y < height && y >= 0 && x < width && x >= 0)	//If the given coordinates is inside the array boundaries
		if(mask[y][x] == 0)			//and if the given square is unopened and unflagged (represented by 0)
			mask[y][x] = 2;			//we set the flag (represented by 2)
		else if(mask[y][x] == 2)		//If the field is flagged
			mask[y][x] = 0;			//we remove the flag (resetting to 0)
}

/**	Part 7f
	The function is similar to setFlag, but a bit extended**/
bool MineSweeper::openSquare(int y, int x){
	if(y < height && y >= 0 && x < width && x >= 0 && mask[y][x] == 0){
		mask[y][x] = 1;			//We open the square (set it to 1) if it is inside the array boundaries and is unopened and unflagged
		if(board[y][x] != -1){		//If it does not contain a mine
			open++;			//We have open a field without a mine and so increment the open member variable
			
			//The next four lines are for the optional part
			if(board[y][x] == 0)
				for(int i = y - 1; i < y + 2; i++)
					for(int j = x - 1; j < x + 2; j++)
						openSquare(i, j);
			
			return false;		//No mine in the opened square, return false
		}
		return true;			//The opened square held a mine, return true, indicating a loss
	}
	return false;				//Did not open a square, return false
		
}

/**	Part 7g **/
void MineSweeper::printBoard(bool showMines){
	for(int j = 0; j < width; j++)
		cout << "\t" << j << ":";			//Prints the column number
	cout << endl << endl;
	for(int i = 0; i < height; i++){
		cout << i << ":\t";				//Prints the row number
		for(int j = 0; j < width; j++){
			if(showMines && board[i][j] == -1)	//If the showMine parameter is true and the square holds a mine (board[i][j] == -1)
				cout << " @ ";			//print a mine
				
			else if(mask[i][j] == 0)		//If the square is unopened (mask[i][j] == 0)
				cout << "| |";			//print an unopened square
				
			else if(mask[i][j] == 1 && board[i][j])	//If the square is opened (mask[i][j] == 1) and it is a neighbor of a mine (board[i][j] != 0)
				cout << " " << board[i][j];	//print an opened square, represented by the number of neighboring mines
				
			else if(mask[i][j] == 2)		//If the square is flagged (mask[i][j] == 2)
				cout << "|X|"; 			//print a flagged square
				
			cout << "\t";				//Print a tab to jump to next column
		}
		cout << endl << endl;				//Print two linefeeds to jump to next row
	}
}

/**	Part 7h **/
void MineSweeper::cleanUpMemory(){
	for(int i = 0; i < height; i++){	//Since both arrays are of same size, we can use the same for-loop for both
		delete[] board[i];		//Use delete[] on each element in the outer arrays
		delete[] mask[i];
	}
	delete[] board;				//And use delete[] on the outer elements them self
	delete[] mask;
}

/**	Part 7i **/
void MineSweeper::play(){
	bool again = true;	//We will run the game as long as this is true,
				//it will be set to false if the player answer
				//no to play again after a completed game. 
	while(again){
		open = 0;		//New game, with no opened squares yet
		getInput();		//Call 3 functions to get game parameters and initiate the board
		makeBoard();
		placeMines();
		bool lost = false;	//New game, not lost or won yet
		bool won = false;
		char c;			//Char for user input
		int x;			//x and y are integers for the user to enter the row
		int y;			//and column of a square he wish to open or place a flag at
		while(!lost && !won){	//Run the game as long as the player has neither won or lost
			system("cls");	//Empty the screen, not necessary, but makes the screen look cleaner
					//(On UNIX/Linux and Mac OS/X systems "cls" should be replaced with "clear")
			printBoard(false);	//Print the board (without showing the mines, hence false)
			cout << "Open " << height * width - mines - open << " more squares to win." << endl;
			cout << "Enter cordinates followed by o to open or f to place/remove flag: ";
			cin >> x >> y >> c;	//Get input from player on square and operation (open/flag)
			if(c == 'f')		//If an 'f' is given by the player
				setFlag(y, x);	//we call the setFlag function
			else if(c == 'o')	//and if 'o' is given we call openSquare
				lost = openSquare(y, x); //If open square returns true, the fields held a mine and lost becomes true
				
						//(If any other character is given we do nothing)
						
			if(open == height * width - mines)
				won = true;	//If the number of squares opened equales the total
						//number of squares (height x width) minus the number
						//of mines, the player has won
		}
		
		//The loop stops when won or lost is true
		
			system("cls");
			printBoard(true);	//Print the board again, this time showing all mines
			
			if(won)			//And print whether the player lost or won
				cout << "You Won!" << endl;
			else
				cout << "You hit a mine! You lost!" << endl;
				
		cleanUpMemory();		//At the end, we clean up the memory
		cout << "Play again (y/n)? ";
		cin >> c;			//and ask if player wants to play again
		again = c == 'y';
	}
}


