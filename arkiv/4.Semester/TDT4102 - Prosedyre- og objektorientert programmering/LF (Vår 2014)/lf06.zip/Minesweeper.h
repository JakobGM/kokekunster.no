#ifndef MINESWEEPER_H
#define MINESWEEPER_H

/**	Part 7a **/
class MineSweeper{
	private:
		int height;
		int width;
		int mines;
		int open;
		int ** board;
		int ** mask;
		
		void getInput();			//Part 7b
		void makeBoard();			//Part 7c
		void placeMines();			//Part 7d
		void setFlag(int y, int x);		//Part 7e
		bool openSquare(int y, int x);		//Part 7f
		void printBoard(bool showMines);	//Part 7g
		void cleanUpMemory();			//Part 7h
	
	public:
		void play();				//Part 7i	
};

#endif
