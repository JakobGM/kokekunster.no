#include "Vector.h"
#include <cmath>


Vector::Vector( const Matrix & other )
		: Matrix() // Start with this as invalid Vector.
{
	
	// If and only if the resultant matrix is valid, assign it.
	if (other.isValid() && other.getColumns() == 1)
		Matrix::operator=(other); // reuse matrix' operator=

	// Need no else, the Vector was already invalid.
		
}

// Alternative implementation
/*Vector::Vector( const Matrix & other )
		: Matrix(other) // Start with this as a copy of other.
{
	if (other.isValid() && other.GetColumns() != 1)
		this->Invalidate();		
}*/



double Vector::dot( const Vector & rhs ) const {
	if ( !this->isValid() || this->getRows() != rhs.getRows())
		return nan("");

	double sum = 0.0;
	for ( unsigned int i = 0; i < this->getColumns(); ++i )
		sum += this->get(i)*rhs.get(i);
	
	return sum;
}

double Vector::lengthSquared() const {
	return this->dot(*this);
}

double Vector::length() const {
	return sqrt( lengthSquared() );
}

