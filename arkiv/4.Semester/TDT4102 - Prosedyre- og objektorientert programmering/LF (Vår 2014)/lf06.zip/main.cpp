#include <iostream>
#include <cstdlib>
#include "Matrix.h"
#include "Vector.h"

using namespace std;

// MACRO magic (Really really not important), but makes for pretty output.
#define STRINGIFY(val) # val
#define PRINT(expr) cout << STRINGIFY(expr)"\n" << (expr) << endl;

int main()
{
	Matrix A(4);
	Matrix Invalid;
	Vector V(4);
	
	Matrix U(0);
	cout << "Valid? " <<  U.isValid() << U /*Does not print anything*/ << endl;
	
	
	Vector C = A*V;
	PRINT(C);
	PRINT(A);
	PRINT(V);
	PRINT(Invalid);
	PRINT(A + V);
	PRINT(A + A);
	PRINT(A * A);
	PRINT(A - A);

	// Test of cross class funtionality
	A = Matrix(8);
	V = Vector(8);
	Vector R;

	for ( int i = 0; i < 8; i++)
		V.at(i) = rand()%10;

	R = A*V;

	PRINT(V);
	PRINT(R);
	

	return 0;
}
