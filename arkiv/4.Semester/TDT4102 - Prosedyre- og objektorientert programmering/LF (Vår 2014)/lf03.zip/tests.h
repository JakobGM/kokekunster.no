#pragma once

void testPart2();
void testPart3();
void testPart4();
