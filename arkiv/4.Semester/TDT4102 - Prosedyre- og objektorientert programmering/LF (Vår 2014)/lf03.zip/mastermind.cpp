#include <iostream>
#include "utilities.h"

using namespace std;

int checkCharactersAndPosition(char code[], char guess[], int size) {
	int count = 0;
	for (int i = 0; i < size; i++) {
		if (code[i] == guess[i]) {
			count++;
		}
	}
	return count;
}

int checkCharacters(char code[], char guess[], int size, int differentLetters) {
	int count = 0;
	for (char character = 'A'; character < 'A' + differentLetters; character++) {
		int occurencesInCode = countOccurencesOfCharacter(code, size, character);
		int occurencesInGuess = countOccurencesOfCharacter(guess, size, character);
		count += min(occurencesInCode, occurencesInGuess);
	}
	return count;
}

void playMastermind() {
	const int SIZE = 4;
	const int LETTERS = 6;

	char code[SIZE + 1] = {0};
	char guess[SIZE + 1] = {0};
	bool playAgain = true;
	while (playAgain) {
		randomizeCString(code, SIZE, 'A', 'A' + LETTERS - 1); // Inclusive limits
		cout << code << endl;
		int attempts = 10;
		while (checkCharactersAndPosition(code, guess, SIZE) < SIZE && attempts > 0) {
			cout << "Guess code: " << endl;
			readInputToCString(guess, SIZE, 'A', 'A' + LETTERS - 1); // Inclusive limits
			int correctCharAndPos = checkCharactersAndPosition(code, guess, SIZE);
			if (correctCharAndPos == SIZE) {
				break;
			}
			cout << " Correct characters (inclusive): " << checkCharacters(code, guess, SIZE, LETTERS) << endl;
			cout << " Correct positions : " << correctCharAndPos << endl;
			attempts--;
			cout << " Attempts left: " << attempts << endl;
		}
		if (checkCharactersAndPosition(code, guess, SIZE) == SIZE) {
			cout << "Congratulations, you won" << endl;
		} else {
			cout << "Better luck next time" << endl;
		}
		cout << "Do you wish to play again? (Y/N)";
		char answer = '\0';
		while (answer != 'Y' && answer != 'N') {
			cin >> answer;
			answer = toupper(answer);
		}
		if (answer == 'N') {
			playAgain = false;
			cout << "Goodbye!" << endl;
		} else {
			playAgain = true;
			cout << "A new round starts now" << endl;
		}
	}
}


