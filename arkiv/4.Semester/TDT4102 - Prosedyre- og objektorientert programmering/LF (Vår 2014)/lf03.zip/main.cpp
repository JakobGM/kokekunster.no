#include <iostream>
#include "tests.h"
#include "mastermind.h"

using namespace std;

int main() {
	srand(time(0));
	int selection = 0;
	while (selection != 1) {
		cout << "Select task to test: " << endl
			<< " 1 : Exit " << endl
			<< " 2 : Call-by-value vs Pekere" << endl
			<< " 3 : Arrays" << endl
			<< " 4 : Char-arrays (C-Strings)" << endl
			<< " 5 : Mastermind" << endl
			<< " 6 : All of the above" << endl;
		cin >> selection;
		switch (selection) {
			case 1:
				break;
			case 2:
				testPart2();
				break;
			case 3:
				testPart3();
				break;
			case 4:
				testPart4();
				break;
			case 5:
				playMastermind();
				break;
			case 6:
				testPart2();
				testPart3();
				testPart4();
				playMastermind();
				break;
			default:
				cout << "Invalid selection" << endl;
				break;
		}
	}

	return 0;
}
