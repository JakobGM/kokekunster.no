#pragma once

int randomWithLimits(int lower, int upper);
char randomCharWithLimits(int lower, int upper);
void incrementByValueNumTimes(int *value, int increment, int numTimes);
void swapNumbers(int *first, int *second);
void printArray(int array[], int size);
void randomizeArray(int array[], int size);
void sortArray(int array[], int size);
int medianOfArray(int array[], int size);
void randomizeCString(char cstring[], int length, int lowerLimit, int upperLimit);
void readInputToCString(char cstring[], int length, int lowerLimit, int upperLimit);
int countOccurencesOfCharacter(char cstring[], int length, char character);
