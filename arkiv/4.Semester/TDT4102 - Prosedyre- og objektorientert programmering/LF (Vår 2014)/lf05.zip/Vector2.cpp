#include "Vector2.h"
#include <cmath>

double Vector2::dot( const Vector2 & rhs ) const {
	return data[0]*rhs.data[0] + data[1]*rhs.data[1];
}

double Vector2::lengthSquared() const {
	return this->dot(*this);
}

double Vector2::length() const {
	return sqrt( lengthSquared() );
}

std::ostream & operator<<( std::ostream & out, const Vector2 & elem )
{
	for ( unsigned int row = 0; row < 2; ++row )
	{
		out << "| ";
			out << elem.Get(row) << ' ';
		out << '|' << std::endl;
	}
	return out;
}

// Optional operators
Vector2 & Vector2::operator+=( const Vector2 & rhs ) {
	data[0] += rhs.data[0];
	data[1] += rhs.data[1];
	return *this;
}

Vector2 & Vector2::operator-=( const Vector2 & rhs ) {
	data[0] -= rhs.data[0];
	data[1] -= rhs.data[1];
	return *this;
}

Vector2 Vector2::operator+( const Vector2 & rhs ) const {
	return Vector2( *this ) += rhs;
}

Vector2 Vector2::operator-( const Vector2 & rhs ) const {
	return Vector2( *this ) -= rhs;
}

Vector2 Vector2::operator-() const { // Unary minus
	return Vector2( -data[0], -data[1] );
}
