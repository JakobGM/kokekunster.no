#include "Matrix2x2.h"
#include "Vector2.h"
#include <ostream>
#include <cstdlib>


double Matrix2x2::Det() const {
	return Get(0,0)*Get(1,1) - Get(0,1)*Get(1,0);
}
	
// We have chosen the second alternative to handle singular matrices.
bool Matrix2x2::Inverse( Matrix2x2 & out ) const
{
	double det = Det();

	// If singular return false
	if ( abs(det) < 1.0e-16 )
		return false;

	// else calculate and return.
	out.Set(0,0,  this->Get(1,1)/det);
	out.Set(0,1, -this->Get(0,1)/det);
	out.Set(1,0, -this->Get(1,0)/det);
	out.Set(1,1,  this->Get(0,0)/det);

	return true;
}

Matrix2x2 & Matrix2x2::operator +=(const Matrix2x2 & rhs) {
	for ( unsigned int row = 0; row < 2; ++row )
		for ( unsigned int column = 0; column < 2; ++column )
			this->data[row][column] += rhs.data[row][column];
	return *this;
}

Matrix2x2 & Matrix2x2::operator -=(const Matrix2x2 & rhs) {
	for ( unsigned int row = 0; row < 2; ++row )
		for ( unsigned int column = 0; column < 2; ++column )
			this->data[row][column] -= rhs.data[row][column];
	return *this;
}

Matrix2x2 Matrix2x2::operator -(const Matrix2x2 & rhs) const {
	return Matrix2x2(*this) -= rhs;
}
	
Matrix2x2 Matrix2x2::operator +(const Matrix2x2 & rhs) const {
	return Matrix2x2(*this) += rhs;
}

Matrix2x2 Matrix2x2::operator *(const Matrix2x2 & rhs) const {
	Matrix2x2 temp;
	for ( unsigned int row = 0; row < 2; ++row )
		for ( unsigned int column = 0; column < 2; ++column )
		{
			temp.data[row][column] = 0.0;
			for ( unsigned int i = 0; i < 2; ++i )
				temp.data[row][column] += this->data[row][i] * rhs.data[i][column];
		}
	return temp;
}

Matrix2x2 & Matrix2x2::operator *=(const Matrix2x2 & rhs) {
	return *this = *this * rhs;
}

Vector2 Matrix2x2::operator*(const Vector2 & rhs ) const {
	double x = this->Get(0,0)*rhs.Get(0);
		   x += this->Get(0,1)*rhs.Get(1);
	double y = this->Get(1,0)*rhs.Get(0) ;
		   y += this->Get(1,1)*rhs.Get(1);
	return Vector2(x, y);
}

std::ostream & operator<<( std::ostream & out, const Matrix2x2 & elem )
{
	for ( unsigned int row = 0; row < 2; ++row )
	{
		out << "| ";
		for ( unsigned int column = 0; column < 2; ++column )
			out << elem.Get(row, column) << ' ';
		out << '|' << std::endl;
	}
	return out;
}

