#pragma once
#include <ostream>

class Vector2 {
private:
	double data[2];
public: 
	Vector2(double x, double y) { 
		data[0] = x; 
		data[1] = y;
	}
	
	Vector2() { 
		data[0] = 0; 
		data[1] = 0;
	}

	double Get(int index) const { 
		return data[index]; 
	}

	void Set(int index, double value) { 
		data[index] = value; 
	}

	double dot( const Vector2 & rhs ) const;
	double lengthSquared() const;
	double length() const;

	// Implementation of optional operators
	Vector2 & operator+=( const Vector2 & rhs );
	Vector2 & operator-=( const Vector2 & rhs );
	Vector2 operator+( const Vector2 & rhs ) const;
	Vector2 operator-( const Vector2 & rhs ) const;

	Vector2 operator-() const; // Unary minus
};

std::ostream & operator<<( std::ostream & out, const Vector2 & elem );
