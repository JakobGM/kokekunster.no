#include <sstream>
#include "card.h"

using namespace std;

string intToString(int i){
    stringstream ss;
    ss << i;
    return ss.str();
}

string rankToString(Rank r){
    switch (r){
        case ACE:
            return "Ace";
        case KING:
            return "King";
        case QUEEN:
            return "Queen";
        case JACK:
            return "Jack";
        default:
            return intToString(r+2);
    }
}

string suitToString(Suit s){
    switch (s){
        case CLUBS:
            return "Clubs";
        case DIAMONDS:
            return "Diamonds";
        case HEARTS:
            return "Hearts";
        case SPADES:
            return "Spades";
    }
}

string toString(CardStruct c){
    string output = rankToString(c.r) + " of " + suitToString(c.s);
    return output;
}

string toStringShort(CardStruct c){
    string output = suitToString(c.s).substr(0,1) + intToString(c.r+2);
    return output;
}

Card::Card(Suit s, Rank r){
    initialize(s,r);
}

Card::Card(){
    invalid = true;
}

string Card::toString(){
    if (invalid) return "Invalid card";
    string output = rankToString(r) + " of " + suitToString(s);
    return output;
}

string Card::toStringShort(){
    if (invalid) return "Invalid card";
    string output = suitToString(s).substr(0,1) + intToString(r+2);
    return output;
}

void Card::initialize(Suit s, Rank r){
    this->s = s;
    this->r = r;
    this->invalid = false;
}

Suit Card::getSuit(){
    return s;
}

Rank Card::getRank(){
    return r;
}

