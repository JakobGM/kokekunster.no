#include <iostream>
#include <cmath>
#include "card.h"
#include "carddeck.h"
#include "blackjack.h"

using namespace std;

int main(){
    srand(time(0));
    Suit s = HEARTS;
    Rank r = KING;
    CardStruct a = {s, r};

    cout << s << endl;
    cout << r << endl;

    cout << suitToString(s) << endl;
    cout << rankToString(r) << endl;

    cout << toString(a) << endl;
    cout << toStringShort(a) << endl;

    Card b(s,r);
    cout << b.toString() << endl;
    cout << b.toStringShort() << endl;
  
    CardDeck d;
    d.shuffle();
    d.print();
    d.printShort();
    
    BlackJack game;
    game.playGame();
    return 0;
}
